function [y]=CreateLapFromSDD(A)
    
    

end